#!/usr/bin/python
# -*- coding: utf-8 -*-



"""
Grobid Experiments
Counts how often a publication/an author is cited in the LREC corpus.
Call: python3 apply_grobid_2.py | sort > out_2
"""



from sys import argv
from sys import stderr
import os
import subprocess
import re
import glob
import xml.etree.ElementTree as ET

# Main
def main():

    #
    #
    # Extract Citations from the papers in folder lrec.
    # The format representing a citation is a triplet
    # zhu   2014    sentimentanalysisofshortinformaltex
    #

    triplets = []
    counter = 0
    for filename in glob.glob('lrec-corpus/*.pdf'):
        triplets = triplets + start_grobid(filename)
        counter += 1
        print ('Document: '+str(counter))


    #
    #
    # Find most frequent citations
    #

    count_citations(triplets)


def start_grobid(filename):

    triplets = []

    # Run Grobid
    command = 'curl -v --form input=@./'+ filename +' localhost:8070/api/processFulltextDocument'
    parsed_file = subprocess.check_output(command, shell=True, executable='/bin/bash')

    parsed_file = str(parsed_file)

    parsed_file = parsed_file.replace('\\n', '\n') 
    parsed_file = parsed_file.replace('\\t', '\t') 
    parsed_file = parsed_file.replace('\\xc3\\xa4', 'ä')
    parsed_file = parsed_file.replace('\\xc3\\xb6', 'ö')
    parsed_file = parsed_file.replace('\\xc3\\xbc', 'ü')
    parsed_file = parsed_file.replace('\\xc3\x84', 'Ä')
    parsed_file = parsed_file.replace('\\xc3\x96', 'Ö')
    parsed_file = parsed_file.replace('\\xc3\\x9c', 'Ü')
    parsed_file = parsed_file.replace('\\xc3\\x9f', 'ß')
    parsed_file = re.sub("^b'", '', parsed_file)
    parsed_file = re.sub("\s+'$", '', parsed_file)
    parsed_file = parsed_file.encode('utf-8')

    # Test output: File in TEI
    #print (parsed_file)

    # Extract citations
    # Create triplet author-year-title
    
    tree = ''
    try:
        tree = ET.fromstring(parsed_file)
    except:
        return triplets

    for element in tree.iter():


        if (re.search('biblStruct', str(element))):
            author = '----'
            forename = '-'
            year = '0000'
            title = '----'
           
            for field in element.iter():

                if (re.search('surname', str(field))):
                    try:
                        author = field.text
                    except:
                        0   

                if (forename == '-' and re.search('forename', str(field))):
                    try:
                        forename = field.text
                        forename.upper()[:1]
                    except:
                        0 

                if (re.search('date', str(field))):
                    try:
                        year = field.attrib['when']
                    except:
                        0

                if (re.search('title', str(field))):
                    try:
                        try_title = field.text
                        if try_title != None and title == '----':
                            title = try_title
                    except:
                        0  

            # Postprocessing of retrieved metadata
            author = author.lower()[:40]
            author = re.sub('[^a-zäöü]', '', author)[:40]
            if author == '':
                author = '----'
            if forename != '-':
                author += forename
            if len(year) > 4:
                year = year[:4]
            title = title.lower()[:40]
            title = re.sub('[^a-zäöü]', '', title)[:40]
            if title == '':
                title = '----'
            triplet = author+'_'+year+'_'+title
            #print (triplet)

            triplets.append(triplet)
    return triplets


def count_citations(triplets):
    
    # Count cited papers
    d = {x:triplets.count(x) for x in triplets}
    for entry in d:
        print ('citedPaper\t'+str(d[entry])+'\t'+entry)

    # Count cited authors
    authors = []
    for line in triplets:
        authors.append(re.sub('_.*', '', line))
    d = {x:authors.count(x) for x in authors}
    for entry in d:
        print ('author\t'+str(d[entry])+'\t'+entry)


if __name__ == '__main__':
    if len(argv) == 1:
        main()
    else:
        stderr.write("Error: Wrong number of arguments.\n")
