#!/usr/bin/python
# -*- coding: utf-8 -*-



"""
Grobid Experiments
Maps the keywords which are given in a publication to the authors/papers which are cited in the publication.
Application: Authors can find the keywords of the publications in which they are cited.
Call: python3 apply_grobid_3.py > out_3
"""



from sys import argv
from sys import stderr
import os
import subprocess
import re
import glob
import xml.etree.ElementTree as ET
from collections import Counter


# Main
def main():

    keywords_by_author = dict()

    counter = 0

    for filename in glob.glob('lrec-corpus/*.pdf'):

        #
        # Extract Citations from Papers.
        # The format representing a citation is a triple
        # zhu   2014    sentimentanalysisofshortinformaltex
        #
        
        keywords_by_author = start_grobid(filename, keywords_by_author)
    
        counter += 1
        print ("Document: "+str(counter))

    count_keywords_by_author(keywords_by_author)



def start_grobid(filename, keywords_by_author):

    # Run Grobid
    command = 'curl -v --form input=@./'+ filename +' localhost:8070/api/processFulltextDocument'
    parsed_file = subprocess.check_output(command, shell=True, executable='/bin/bash')

    parsed_file = str(parsed_file)

    parsed_file = parsed_file.replace('\\n', '\n') 
    parsed_file = parsed_file.replace('\\t', '\t') 
    parsed_file = parsed_file.replace('\\xc3\\xa4', 'ä')
    parsed_file = parsed_file.replace('\\xc3\\xb6', 'ö')
    parsed_file = parsed_file.replace('\\xc3\\xbc', 'ü')
    parsed_file = parsed_file.replace('\\xc3\x84', 'Ä')
    parsed_file = parsed_file.replace('\\xc3\x96', 'Ö')
    parsed_file = parsed_file.replace('\\xc3\\x9c', 'Ü')
    parsed_file = parsed_file.replace('\\xc3\\x9f', 'ß')
    parsed_file = re.sub("^b'", '', parsed_file)
    parsed_file = re.sub("\s+'$", '', parsed_file)
    parsed_file = parsed_file.encode('utf-8')

    # Test output: File in TEI
    #print (parsed_file)

    
    keywords = []
    tree = ''
    try:
        tree = ET.fromstring(parsed_file)
    except:
        return keywords_by_author


    for element in tree.iter():

        if (re.search('keywords', str(element))):
            for field in element.iter():
                if (re.search('term', str(field))):
                    keywords.append(field.text)



        if (re.search('biblStruct', str(element))):
            author = '----'
            forename = '-'
           
            for field in element.iter():

                if (re.search('surname', str(field))):
                    try:
                        author = field.text
                    except:
                        0   

                if (forename == '-' and re.search('forename', str(field))):
                    try:
                        forename = field.text
                        forename.upper()[:1]
                    except:
                        0 


            # Postprocessing of retrieved metadata
            author = author.lower()[:40]
            author = re.sub('[^a-zäöü]', '', author)[:40]
            if author == '':
                author = '----'
            if forename != '-':
                author += forename


            list_of_keywords = []
            if author in keywords_by_author:
                list_of_keywords = keywords_by_author[author]

            for entry in keywords:
                list_of_keywords.append(entry)
                
            keywords_by_author[author] = list_of_keywords


    return keywords_by_author


def count_keywords_by_author(keywords_by_author):

    for entry in keywords_by_author:

        string_to_print = entry + ' => '

        string_to_print += ' , '.join(keywords_by_author[entry])

        string_to_print = string_to_print.replace(' =>  ,', ' => ')
        print (string_to_print)
        print ('')


if __name__ == '__main__':
    if len(argv) == 1:
        main()
    else:
        stderr.write("Error: Wrong number of arguments.\n")
