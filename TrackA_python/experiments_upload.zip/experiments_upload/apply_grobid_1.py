#!/usr/bin/python
# -*- coding: utf-8 -*-



"""
Grobid Experiments
Extracts citations and converts the output in a format which ressebles BibTeX.
Call: python3 apply_grobid_1.py > out_1
"""



from sys import argv
from sys import stderr
import os
import subprocess
import re
import xml.etree.ElementTree as ET
import glob


# Main
def main():

    # Read PDF files in the folder "lrec"
    for filename in glob.glob('lrec/*.pdf'):
        start_grobid(filename)    



def start_grobid(filename):
    
    # Run Grobid
    command = 'curl -v --form input=@./'+ filename +' localhost:8070/api/processFulltextDocument'
    parsed_file = subprocess.check_output(command, shell=True, executable='/bin/bash')

    parsed_file = str(parsed_file)

    parsed_file = parsed_file.replace('\\n', '\n') 
    parsed_file = parsed_file.replace('\\t', '\t') 
    parsed_file = parsed_file.replace('\\xc3\\xa4', 'ä')
    parsed_file = parsed_file.replace('\\xc3\\xb6', 'ö')
    parsed_file = parsed_file.replace('\\xc3\\xbc', 'ü')
    parsed_file = parsed_file.replace('\\xc3\x84', 'Ä')
    parsed_file = parsed_file.replace('\\xc3\x96', 'Ö')
    parsed_file = parsed_file.replace('\\xc3\\x9c', 'Ü')
    parsed_file = parsed_file.replace('\\xc3\\x9f', 'ß')
    parsed_file = re.sub("^b'", '', parsed_file)
    parsed_file = re.sub("\s+'$", '', parsed_file)
    parsed_file = parsed_file.encode('utf-8')

    # Print Grobid XML file
    #print (parsed_file)


    # Extract Citation Metadata

    tree = ''
    try:
        tree = ET.fromstring(parsed_file)
    except:
        return keywords_by_author

    for element in tree.iter():



        if (re.search('titleStmt', str(element))):
            for field in element.iter():
                if (re.search("title'", str(field))):
                    print ('Paper:')
                    #print (field.text)



        if (re.search('biblStruct', str(element))):
            year = '0000'
            title = '----'
            author = '----'            
            for field in element.iter():


                if (re.search('date', str(field))):
                    try:
                        year = field.attrib['when']
                    except:
                        0

                if (re.search('title', str(field))):
                    try:
                        try_title = field.text
                        if try_title != None and title == '----':
                            title = try_title
                    except:
                        0  

                if (re.search('surname', str(field))):
                    try:
                        author = field.text
                    except:
                        0   

            if len(year) > 4:
                year = year[:4]

            # Output data in a format which ressembles BibTeX
            print ('@article{'+author.lower()+year+',')
            print ('author = {'+author+'},')
            print ('year = {'+year+'},')
            print ('title = {'+title+'},')
            print ('}')
            print ('')

if __name__ == '__main__':
    if len(argv) == 1:
        main()
    else:
        stderr.write("Error: Wrong number of arguments.\n")
